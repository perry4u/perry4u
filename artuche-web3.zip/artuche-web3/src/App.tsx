import React from "react";
import { Route, Switch } from "wouter";
import Header from "./components/Header";
import Footer from "./components/Footer";

import Home from "./pages/Home";
import Dashboard from "./pages/Dashboard";
import Payments from "./pages/Payments";
import Admin from "./pages/Admin";
import About from "./pages/About";
import Studio from "./pages/Studio";
import Labs from "./pages/Labs";
import Academy from "./pages/Academy";
import Originals from "./pages/Originals";
import Contact from "./pages/Contact";

function NotFound() {
  return (
    <div className="container" style={{ padding: "70px 0" }}>
      <div className="card">
        <h2 className="h2">Page Not Found</h2>
        <p className="p">The route you requested doesn’t exist.</p>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <>
      <Header />
      <main>
        <Switch>
          <Route path="/" component={Home} />
          <Route path="/dashboard" component={Dashboard} />
          <Route path="/payments" component={Payments} />
          <Route path="/admin" component={Admin} />
          <Route path="/about" component={About} />
          <Route path="/studio" component={Studio} />
          <Route path="/labs" component={Labs} />
          <Route path="/academy" component={Academy} />
          <Route path="/originals" component={Originals} />
          <Route path="/contact" component={Contact} />
          <Route component={NotFound} />
        </Switch>
      </main>
      <Footer />
    </>
  );
}
