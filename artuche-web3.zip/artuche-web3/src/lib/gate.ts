export const GATE_STORAGE_KEY = "artuche_gate_signature";
export function saveGateSignature(sig: string) { sessionStorage.setItem(GATE_STORAGE_KEY, sig); }
export function getGateSignature() { return sessionStorage.getItem(GATE_STORAGE_KEY); }
export function clearGateSignature() { sessionStorage.removeItem(GATE_STORAGE_KEY); }
export function isGatedIn() { return !!getGateSignature(); }
