import { isAddress } from "viem";

export type Role = "MEMBER" | "FOUNDER" | "ADMIN";

export function getAdminList(): string[] {
  const raw = (import.meta.env.VITE_ADMIN_ADDRESSES as string | undefined) ?? "";
  return raw.split(",").map(s => s.trim()).filter(Boolean);
}

export function isAdmin(address?: string | null): boolean {
  if (!address) return false;
  const admins = getAdminList().map(a => a.toLowerCase());
  return admins.includes(address.toLowerCase());
}

export function getRoleContracts(): string[] {
  const raw = (import.meta.env.VITE_ROLE_NFT_CONTRACTS as string | undefined) ?? "";
  return raw.split(",").map(s => s.trim()).filter(Boolean).filter(a => isAddress(a));
}
