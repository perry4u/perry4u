import React from "react";
import { Link } from "wouter";

const items = [
  { title: "ARTUCHE Studio", desc: "Brand systems, digital experiences, creative direction.", to: "/studio" },
  { title: "ARTUCHE Labs", desc: "Innovation, AI frameworks, tools, and IP.", to: "/labs" },
  { title: "ARTUCHE Academy", desc: "Future-skills training and talent development.", to: "/academy" },
  { title: "ARTUCHE Originals", desc: "Media, culture, and long-term intellectual property.", to: "/originals" },
];

export default function Ecosystem() {
  return (
    <div className="grid3">
      {items.map((x) => (
        <div key={x.title} className="card" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>{x.title}</div>
          <p className="p">{x.desc}</p>
          <div style={{ marginTop: "auto" }}>
            <Link href={x.to} className="btn">Explore</Link>
          </div>
        </div>
      ))}
    </div>
  );
}
