import React from "react";
export default function Section(props: { title?: string; kicker?: string; children: React.ReactNode; }) {
  return (
    <section style={{ padding: "42px 0" }}>
      <div className="container">
        {props.kicker && <div className="pill">{props.kicker}</div>}
        {props.title && <h2 className="h2" style={{ marginTop: 14 }}>{props.title}</h2>}
        <div>{props.children}</div>
      </div>
    </section>
  );
}
