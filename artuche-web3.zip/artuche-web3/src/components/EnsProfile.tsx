import React, { useEffect, useState } from "react";
import { useAccount, usePublicClient } from "wagmi";

export default function EnsProfile() {
  const { address } = useAccount();
  const client = usePublicClient({ chainId: 1 }); // ENS is mainnet
  const [name, setName] = useState<string>("");
  const [avatar, setAvatar] = useState<string>("");
  const [err, setErr] = useState<string>("");

  useEffect(() => {
    let alive = true;
    async function load() {
      setErr("");
      setName("");
      setAvatar("");
      if (!address || !client) return;

      try {
        const ensName = await client.getEnsName({ address });
        if (!alive) return;
        if (ensName) {
          setName(ensName);
          const av = await client.getEnsAvatar({ name: ensName });
          if (!alive) return;
          if (av) setAvatar(av);
        }
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message ?? "ENS lookup failed");
      }
    }
    load();
    return () => { alive = false; }
  }, [address, client]);
  return (
    <div className="card">
      <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>ENS Profile</div>
      <div className="small">Mainnet ENS lookup (name + avatar).</div>
      <div className="hr" />
      {!address ? (
        <p className="p">Connect your wallet to see ENS.</p>
      ) : err ? (
        <p className="p">Error: {err}</p>
      ) : name ? (
        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
          {avatar ? (
            <img src={avatar} alt="ENS avatar" style={{ width: 52, height: 52, borderRadius: 14, border: "1px solid rgba(255,255,255,.12)" }} />
          ) : (
            <div style={{ width: 52, height: 52, borderRadius: 14, border: "1px solid rgba(255,255,255,.12)" }} />
          )}
          <div>
            <div style={{ fontSize: 16, letterSpacing: ".02em" }}><b>{name}</b></div>
            <div className="small">If no ENS is set, this section stays empty.</div>
          </div>
        </div>
      ) : (
        <p className="p">No ENS name found for this wallet.</p>
      )}
    </div>
  );
}
