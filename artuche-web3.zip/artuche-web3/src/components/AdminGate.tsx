import React from "react";
import { useAccount } from "wagmi";
import { isAdmin } from "../lib/roles";
import { Link } from "wouter";

export default function AdminGate({ children }: { children: React.ReactNode }) {
  const { address, isConnected } = useAccount();
  const ok = isConnected && isAdmin(address);

  if (ok) return <>{children}</>;

  return (
    <div className="card">
      <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Admin Only</div>
      <p className="p" style={{ marginTop: 10 }}>
        This page is restricted. Add your wallet to <code>VITE_ADMIN_ADDRESSES</code> in <code>.env</code>.
      </p>
      <div className="btnRow" style={{ marginTop: 12 }}>
        <Link className="btn btnPrimary" href="/">Go to Home</Link>
        <Link className="btn" href="/dashboard">Open Dashboard</Link>
      </div>
    </div>
  );
}
