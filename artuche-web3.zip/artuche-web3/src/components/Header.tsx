import React from "react";
import { Link, useLocation } from "wouter";

const nav = [
  ["Home", "/"],
  ["Dashboard", "/dashboard"],
  ["Payments", "/payments"],
  ["About", "/about"],
  ["Studio", "/studio"],
  ["Labs", "/labs"],
  ["Academy", "/academy"],
  ["Originals", "/originals"],
  ["Contact", "/contact"],
  ["Admin", "/admin"],
] as const;

export default function Header() {
  const [loc] = useLocation();
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 30, backdropFilter: "blur(10px)", borderBottom: "1px solid rgba(255,255,255,.08)", background: "rgba(0,0,0,.55)" }}>
      <div className="container" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "14px 0", gap: 16 }}>
        <Link href="/" style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{ width: 34, height: 34, borderRadius: 10, border: "1px solid rgba(255,255,255,.14)", background: "linear-gradient(135deg, rgba(0,255,255,.18), rgba(125,90,255,.22))" }} />
          <div style={{ letterSpacing: ".14em", textTransform: "uppercase" }}>ARTUCHE</div>
        </Link>

        <nav style={{ display: "flex", gap: 14, flexWrap: "wrap", justifyContent: "flex-end" }}>
          {nav.map(([label, href]) => {
            const active = loc === href;
            return (
              <Link key={href} href={href} className="pill" style={{ padding: "8px 10px", borderColor: active ? "rgba(255,255,255,.25)" : "rgba(255,255,255,.12)", color: active ? "rgba(255,255,255,.92)" : "rgba(255,255,255,.72)" }}>
                {label}
              </Link>
            );
          })}
        </nav>
      </div>
    </header>
  );
}
