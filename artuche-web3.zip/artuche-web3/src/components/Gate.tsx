import React from "react";
import { useAccount } from "wagmi";
import { isGatedIn } from "../lib/gate";
import { Link } from "wouter";

export default function Gate({ children }: { children: React.ReactNode }) {
  const { isConnected } = useAccount();
  const ok = isConnected && isGatedIn();

  if (ok) return <>{children}</>;

  return (
    <div className="card">
      <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Locked</div>
      <p className="p" style={{ marginTop: 10 }}>
        This section is gated. Connect your wallet and use <b>Gate Sign-In</b> to unlock.
      </p>
      <div className="btnRow" style={{ marginTop: 12 }}>
        <Link className="btn btnPrimary" href="/">Go to Home (Web3 Access)</Link>
        <Link className="btn" href="/dashboard">Open Dashboard</Link>
      </div>
    </div>
  );
}
