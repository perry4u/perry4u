import React, { useMemo, useState } from "react";
import { useAccount, useConnect, useDisconnect, useSignMessage, useChainId } from "wagmi";
import { clearGateSignature, isGatedIn, saveGateSignature } from "../lib/gate";

export default function Web3Panel() {
  const { address, isConnected } = useAccount();
  const { connectors, connectAsync, isPending } = useConnect();
  const { disconnect } = useDisconnect();
  const chainId = useChainId();

  const [sig, setSig] = useState<string>("");
  const [gateStatus, setGateStatus] = useState<boolean>(isGatedIn());
  const { signMessageAsync, isPending: signing } = useSignMessage();

  const shortAddr = useMemo(() => {
    if (!address) return "";
    return `${address.slice(0, 6)}…${address.slice(-4)}`;
  }, [address]);

  async function onConnect(i: number) {
    setSig("");
    await connectAsync({ connector: connectors[i] });
  }

  async function onSignDemo() {
    const message = `ARTUCHE Verification\nTime: ${new Date().toISOString()}\nPurpose: Signature demo only (no transactions).`;
    const res = await signMessageAsync({ message });
    setSig(res);
  }

  async function onGateSignIn() {
    if (!address) return;
    const message =
      `ARTUCHE GATE ACCESS\n` +
      `Wallet: ${address}\n` +
      `Time: ${new Date().toISOString()}\n` +
      `Purpose: Unlock gated ecosystem sections.\n` +
      `Note: No transactions, no approvals.`;

    const res = await signMessageAsync({ message });
    saveGateSignature(res);
    setGateStatus(true);
  }

  function onGateSignOut() {
    clearGateSignature();
    setGateStatus(false);
  }

  return (
    <div className="card">
      <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 12, flexWrap: "wrap" }}>
        <div>
          <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Web3 Access</div>
          <div className="small">Connect wallet for dashboard, tokens, NFTs, and gated content (no transactions).</div>
        </div>

        {isConnected ? (
          <div className="pill">
            Connected: <b style={{ color: "white" }}>{shortAddr}</b> • ChainID:{" "}
            <b style={{ color: "white" }}>{chainId}</b>
            {gateStatus ? (
              <span style={{ marginLeft: 10 }}>• ✅ Gated In</span>
            ) : (
              <span style={{ marginLeft: 10 }}>• 🔒 Locked</span>
            )}
          </div>
        ) : (
          <div className="pill">Not connected</div>
        )}
      </div>

      <div className="hr" />

      {!isConnected ? (
        <div className="btnRow">
          {connectors.map((c, idx) => (
            <button key={c.uid} className={"btn btnPrimary"} disabled={isPending} onClick={() => onConnect(idx)}>
              {isPending ? "Connecting…" : `Connect: ${c.name}`}
            </button>
          ))}
          {typeof window !== "undefined" && !(window as any).ethereum ? (
            <div className="small" style={{ color: "#f59e0b" }}>
              MetaMask not detected. <a href="https://metamask.io/download/" target="_blank" rel="noopener noreferrer" style={{ color: "#60a5fa", textDecoration: "underline" }}>Install MetaMask</a> to connect your wallet.
            </div>
          ) : (
            <div className="small">Tip: Click "Connect: Injected" for MetaMask, or add WalletConnect Project ID in <code>.env</code>.</div>
          )}
        </div>
      ) : (
        <div className="btnRow">
          <button className="btn btnPrimary" disabled={signing} onClick={onGateSignIn}>
            {signing ? "Signing…" : "Gate Sign-In (Unlock)"}
          </button>

          <button className="btn" disabled={!gateStatus} onClick={onGateSignOut}>
            Gate Sign-Out
          </button>

          <button className="btn" disabled={signing} onClick={onSignDemo}>
            {signing ? "Signing…" : "Sign Message (Demo)"}
          </button>

          <button className="btn" onClick={() => disconnect()}>
            Disconnect
          </button>
        </div>
      )}

      {sig && (
        <div style={{ marginTop: 12 }}>
          <div className="small">Latest Signature:</div>
          <div className="card" style={{ padding: 12, marginTop: 6, overflowWrap: "anywhere" }}>
            <code style={{ color: "rgba(255,255,255,.85)" }}>{sig}</code>
          </div>
        </div>
      )}
    </div>
  );
}
