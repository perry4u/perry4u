import React from "react";
import { Link } from "wouter";

export default function Footer() {
  return (
    <footer style={{ borderTop: "1px solid rgba(255,255,255,.10)", padding: "28px 0", background: "rgba(0,0,0,.35)" }}>
      <div className="container" style={{ display: "flex", gap: 18, justifyContent: "space-between", flexWrap: "wrap" }}>
        <div>
          <div style={{ letterSpacing: ".14em", textTransform: "uppercase" }}>ARTUCHE</div>
          <div className="small" style={{ marginTop: 6 }}>Creative Intelligence Ecosystem</div>
        </div>

        <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
          <Link href="/studio" className="pill">Studio</Link>
          <Link href="/labs" className="pill">Labs</Link>
          <Link href="/academy" className="pill">Academy</Link>
          <Link href="/contact" className="pill">Contact</Link>
        </div>

        <div className="small">© {new Date().getFullYear()} ARTUCHE. All rights reserved.</div>
      </div>
    </footer>
  );
}
