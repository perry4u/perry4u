import React, { useEffect, useMemo, useState } from "react";
import { useAccount } from "wagmi";
import { getRoleContracts, isAdmin, type Role } from "../lib/roles";

type RoleState = {
  role: Role;
  reasons: string[];
};

export default function NFTRoles() {
  const { address } = useAccount();
  const key = import.meta.env.VITE_ALCHEMY_API_KEY as string | undefined;
  const network = (import.meta.env.VITE_ALCHEMY_NETWORK as string | undefined) ?? "eth-mainnet";
  const contracts = useMemo(() => getRoleContracts(), []);
  const [state, setState] = useState<RoleState>({ role: "MEMBER", reasons: [] });
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;
    async function load() {
      setErr("");
      setState({ role: "MEMBER", reasons: [] });
      if (!address) return;

      // Admin override from env list
      if (isAdmin(address)) {
        setState({ role: "ADMIN", reasons: ["Wallet is in admin allowlist."] });
        return;
      }

      if (!key) {
        setErr("Missing VITE_ALCHEMY_API_KEY in .env (needed for NFT role checks).");
        return;
      }
      if (contracts.length === 0) {
        setErr("No role NFT contracts configured. Add VITE_ROLE_NFT_CONTRACTS in .env");
        return;
      }

      setLoading(true);
      try {
        // Query NFTs for owner, filtered by contract addresses (Alchemy supports contractAddresses param)
        const params = new URLSearchParams({
          owner: address,
          withMetadata: "false",
          pageSize: "100"
        });
        // Alchemy expects repeated contractAddresses[] keys
        for (const c of contracts) params.append("contractAddresses[]", c);

        const url = `https://${network}.g.alchemy.com/nft/v3/${key}/getNFTsForOwner?${params.toString()}`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`Alchemy error: ${res.status}`);
        const json = await res.json();

        const owned = (json?.ownedNfts ?? []) as any[];
        const hasRoleNft = owned.length > 0;

        if (!alive) return;

        if (hasRoleNft) {
          setState({
            role: "FOUNDER",
            reasons: [`Owns ${owned.length} NFT(s) from role contract list.`],
          });
        } else {
          setState({
            role: "MEMBER",
            reasons: ["No role NFTs detected from configured contracts."],
          });
        }
      } catch (e: any) {
        if (!alive) return;
        setErr(e?.message ?? "Failed to check roles");
      } finally {
        if (alive) setLoading(false);
      }
    }

    load();
    return () => { alive = false; };
  }, [address, key, network, contracts]);

  return (
    <div className="card">
      <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Member Role</div>
      <div className="small">Role logic: ADMIN (allowlist) → FOUNDER (owns role NFT) → MEMBER.</div>
      <div className="hr" />

      {!address ? (
        <p className="p">Connect wallet to evaluate roles.</p>
      ) : loading ? (
        <p className="p">Checking…</p>
      ) : err ? (
        <p className="p">Error: {err}</p>
      ) : (
        <>
          <div className="pill" style={{ justifyContent: "space-between", width: "100%" }}>
            <span>Role</span>
            <b style={{ color: "white" }}>{state.role}</b>
          </div>
          <div style={{ marginTop: 10, display: "grid", gap: 8 }}>
            {state.reasons.map((r, i) => (
              <div key={i} className="small">• {r}</div>
            ))}
          </div>
        </>
      )}
    </div>
  );
}
