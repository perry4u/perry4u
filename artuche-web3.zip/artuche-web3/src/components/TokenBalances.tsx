import React, { useEffect, useState } from "react";
import { useAccount, usePublicClient } from "wagmi";
import { formatUnits, isAddress } from "viem";

const erc20Abi = [
  { type: "function", name: "symbol", stateMutability: "view", inputs: [], outputs: [{ type: "string" }] },
  { type: "function", name: "decimals", stateMutability: "view", inputs: [], outputs: [{ type: "uint8" }] },
  { type: "function", name: "balanceOf", stateMutability: "view", inputs: [{ type: "address" }], outputs: [{ type: "uint256" }] },
] as const;

const TOKENS = [
  { name: "USDC", address: "0xA0b86991c6218b36c1d19D4a2e9Eb0cE3606eB48" },
  { name: "USDT", address: "0xdAC17F958D2ee523a2206206994597C13D831ec7" },
  { name: "DAI",  address: "0x6B175474E89094C44Da98b954EedeAC495271d0F" },
] as const;

type Row = { token: string; balance: string; raw: bigint };

export default function TokenBalances() {
  const { address } = useAccount();
  const client = usePublicClient();
  const [rows, setRows] = useState<Row[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState<string>("");

  useEffect(() => {
    let alive = true;
    async function load() {
      setErr("");
      setRows([]);
      if (!address || !client) return;

      setLoading(true);
      try {
        const out: Row[] = [];
        for (const t of TOKENS) {
          if (!isAddress(t.address)) continue;

          const [symbol, decimals, bal] = await Promise.all([
            client.readContract({ abi: erc20Abi, address: t.address, functionName: "symbol" }),
            client.readContract({ abi: erc20Abi, address: t.address, functionName: "decimals" }),
            client.readContract({ abi: erc20Abi, address: t.address, functionName: "balanceOf", args: [address] }),
          ]);

          const formatted = formatUnits(bal, decimals);
          out.push({ token: symbol ?? t.name, balance: formatted, raw: bal });
        }

        if (alive) setRows(out);
      } catch (e: any) {
        if (alive) setErr(e?.message ?? "Failed to load balances");
      } finally {
        if (alive) setLoading(false);
      }
    }

    load();
    return () => { alive = false; };
  }, [address, client]);

  return (
    <div className="card">
      <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Token Balances</div>
      <div className="small">Onchain read (ERC-20 balanceOf). Edit token list inside this component.</div>
      <div className="hr" />
      {!address ? (
        <p className="p">Connect your wallet to view balances.</p>
      ) : loading ? (
        <p className="p">Loading…</p>
      ) : err ? (
        <p className="p">Error: {err}</p>
      ) : rows.length === 0 ? (
        <p className="p">No balances found (or you hold none of the listed tokens).</p>
      ) : (
        <div style={{ display: "grid", gap: 10 }}>
          {rows.map((r) => (
            <div key={r.token} className="pill" style={{ justifyContent: "space-between" }}>
              <span>{r.token}</span>
              <b style={{ color: "white" }}>{r.balance}</b>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
