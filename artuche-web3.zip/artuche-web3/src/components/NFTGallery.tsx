import React, { useEffect, useState } from "react";
import { useAccount } from "wagmi";

type NftItem = { name?: string; image?: string; contract?: string; tokenId?: string; };

function normalizeImage(url?: string) {
  if (!url) return "";
  if (url.startsWith("ipfs://")) return url.replace("ipfs://", "https://ipfs.io/ipfs/");
  return url;
}

export default function NFTGallery() {
  const { address } = useAccount();
  const key = import.meta.env.VITE_ALCHEMY_API_KEY as string | undefined;
  const network = (import.meta.env.VITE_ALCHEMY_NETWORK as string | undefined) ?? "eth-mainnet";

  const [items, setItems] = useState<NftItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    let alive = true;
    async function load() {
      setErr("");
      setItems([]);
      if (!address) return;
      if (!key) { setErr("Missing VITE_ALCHEMY_API_KEY in .env"); return; }

      setLoading(true);
      try {
        const url = `https://${network}.g.alchemy.com/nft/v3/${key}/getNFTsForOwner?owner=${address}&withMetadata=true&pageSize=30`;
        const res = await fetch(url);
        if (!res.ok) throw new Error(`Alchemy error: ${res.status}`);
        const json = await res.json();

        const mapped: NftItem[] = (json?.ownedNfts ?? []).map((n: any) => {
          const img =
            n?.image?.cachedUrl ||
            n?.image?.pngUrl ||
            n?.image?.thumbnailUrl ||
            n?.raw?.metadata?.image ||
            n?.metadata?.image;

          return {
            name: n?.name || n?.raw?.metadata?.name || "Untitled",
            image: normalizeImage(img),
            contract: n?.contract?.address,
            tokenId: n?.tokenId,
          };
        });

        if (alive) setItems(mapped.filter((x) => !!x.image));
      } catch (e: any) {
        if (alive) setErr(e?.message ?? "Failed to load NFTs");
      } finally {
        if (alive) setLoading(false);
      }
    }

    load();
    return () => { alive = false; };
  }, [address, key, network]);

  return (
    <div className="card">
      <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>NFT Gallery</div>
      <div className="small">Uses Alchemy NFT API. Set VITE_ALCHEMY_API_KEY in .env</div>
      <div className="hr" />
      {!address ? (
        <p className="p">Connect your wallet to view NFTs.</p>
      ) : loading ? (
        <p className="p">Loading…</p>
      ) : err ? (
        <p className="p">Error: {err}</p>
      ) : items.length === 0 ? (
        <p className="p">No NFTs found (or none with images returned).</p>
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 12 }}>
          {items.map((n, idx) => (
            <div key={idx} className="card" style={{ padding: 12 }}>
              <div style={{ borderRadius: 14, overflow: "hidden", border: "1px solid rgba(255,255,255,.10)" }}>
                <img src={n.image} alt={n.name} style={{ width: "100%", display: "block" }} />
              </div>
              <div style={{ marginTop: 10, fontSize: 13, letterSpacing: ".04em" }}>{n.name}</div>
              <div className="small" style={{ marginTop: 6, overflowWrap: "anywhere" }}>
                {n.contract?.slice(0, 8)}…{n.contract?.slice(-6)} • #{n.tokenId?.slice(0, 10)}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
