import React from "react";
import Section from "../components/Section";
import Gate from "../components/Gate";

export default function Labs() {
  return (
    <Section title="ARTUCHE Labs" kicker="Innovation Engine">
      <Gate>
        <div className="card">
          <p className="p">
            ARTUCHE Labs is where experimentation becomes intellectual property. We prototype tools and frameworks across
            AI + creativity, digital identity, and cultural technology.
          </p>
          <div className="hr" />
          <p className="p">
            Gated content example: research notes, prototypes, partner docs, private roadmaps.
          </p>
        </div>
      </Gate>
    </Section>
  );
}
