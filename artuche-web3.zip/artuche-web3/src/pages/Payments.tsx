import React, { useMemo, useState } from "react";
import Section from "../components/Section";
import { useAccount, useSendTransaction } from "wagmi";
import { parseEther, isAddress } from "viem";

export default function Payments() {
  const stripeLink = import.meta.env.VITE_STRIPE_PAYMENT_LINK as string | undefined;
  const { address: from } = useAccount();

  const [to, setTo] = useState<string>("");
  const [amount, setAmount] = useState<string>("0.01");
  const [note, setNote] = useState<string>("ARTUCHE service payment");
  const [txHash, setTxHash] = useState<string>("");

  const { sendTransactionAsync, isPending, error } = useSendTransaction();

  const toOk = useMemo(() => isAddress(to), [to]);

  async function payEth() {
    setTxHash("");
    if (!toOk) return;
    const hash = await sendTransactionAsync({
      to: to as any,
      value: parseEther(amount || "0")
    });
    setTxHash(hash);
  }

  return (
    <>
      <Section title="Payments" kicker="Monetization Layer">
        <div className="grid3">
          <div className="card" style={{ gridColumn: "span 2" as any }}>
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Pay with Card (Stripe)</div>
            <div className="small">Use a Stripe Payment Link for instant checkout (no backend).</div>
            <div className="hr" />
            {stripeLink ? (
              <a className="btn btnPrimary" href={stripeLink} target="_blank" rel="noreferrer">Open Stripe Checkout</a>
            ) : (
              <p className="p">Add <code>VITE_STRIPE_PAYMENT_LINK</code> to your <code>.env</code>.</p>
            )}
          </div>

          <div className="card">
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Pay with ETH</div>
            <div className="small">Simple wallet payment (send ETH to an address).</div>
            <div className="hr" />

            <div style={{ display: "grid", gap: 10 }}>
              <input className="btn" style={{ textAlign: "left" }} placeholder="Recipient address (0x...)" value={to} onChange={(e) => setTo(e.target.value.trim())} />
              <input className="btn" style={{ textAlign: "left" }} placeholder="Amount in ETH" value={amount} onChange={(e) => setAmount(e.target.value)} />
              <input className="btn" style={{ textAlign: "left" }} placeholder="Note (optional)" value={note} onChange={(e) => setNote(e.target.value)} />

              <button className="btn btnPrimary" disabled={!from || !toOk || isPending} onClick={payEth}>
                {isPending ? "Sending…" : "Send ETH"}
              </button>

              {!from && <div className="small">Connect your wallet first.</div>}
              {to && !toOk && <div className="small">Recipient address is invalid.</div>}
              {error && <div className="small">Error: {error.message}</div>}
              {txHash && <div className="small">Tx Hash: {txHash}</div>}
            </div>
          </div>
        </div>

        <div style={{ marginTop: 14 }} className="small">
          Tip: For full invoicing + subscriptions, Stripe Checkout Sessions require a backend. Payment Links are fastest.
        </div>
      </Section>
    </>
  );
}
