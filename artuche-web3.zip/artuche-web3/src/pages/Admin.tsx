import React from "react";
import Section from "../components/Section";
import AdminGate from "../components/AdminGate";

export default function Admin() {
  return (
    <Section title="Admin Panel" kicker="Restricted">
      <AdminGate>
        <div className="card">
          <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Admin Actions</div>
          <p className="p" style={{ marginTop: 10 }}>
            This is a placeholder. Add tools here: member exports, gated content upload links, analytics, etc.
          </p>
        </div>
      </AdminGate>
    </Section>
  );
}
