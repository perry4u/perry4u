import React, { useState } from "react";
import Section from "../components/Section";

export default function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <Section title="Contact" kicker="Start Here">
      <div className="card">
        <p className="p">Send a message and we’ll respond with next steps and a discovery call link.</p>
        <div className="hr" />

        <form onSubmit={(e) => { e.preventDefault(); setSent(true); }} style={{ display: "grid", gap: 10 }}>
          <input className="btn" style={{ textAlign: "left" }} placeholder="Name" required />
          <input className="btn" style={{ textAlign: "left" }} placeholder="Email" type="email" required />
          <input className="btn" style={{ textAlign: "left" }} placeholder="Project Type (Studio / Labs / Academy / Originals)" required />
          <textarea className="btn" style={{ textAlign: "left", minHeight: 120 }} placeholder="Message" required />
          <button className="btn btnPrimary" type="submit">Send</button>

          {sent && (
            <div className="pill" style={{ marginTop: 8 }}>
              Sent (demo). Connect this to EmailJS, Formspree, or a backend API when ready.
            </div>
          )}
          <div className="small">Web3 note: you can use wallet signature as a verification layer.</div>
        </form>
      </div>
    </Section>
  );
}
