import React from "react";
import Section from "../components/Section";

export default function About() {
  return (
    <Section title="About ARTUCHE" kicker="Identity">
      <div className="card">
        <p className="p">
          ARTUCHE is a creative intelligence ecosystem operating at the intersection of design, culture, technology,
          and human potential. We build systems — not trends — for a future that keeps changing.
        </p>
        <div className="hr" />
        <p className="p">
          Our work prioritises continuity, clarity, and meaning. When platforms shift, ARTUCHE systems adapt.
          This is infrastructure.
        </p>
      </div>
    </Section>
  );
}
