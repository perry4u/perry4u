import React from "react";
import Section from "../components/Section";
import { Link } from "wouter";

export default function Studio() {
  return (
    <Section title="ARTUCHE Studio" kicker="Money Engine">
      <div className="grid3">
        <div className="card">
          <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Future Brand Identity</div>
          <p className="p">Logos, systems, guidelines, and brand direction built for longevity.</p>
        </div>
        <div className="card">
          <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Digital Experience Design</div>
          <p className="p">Web and platform UI that feels premium, modern, and structured.</p>
        </div>
        <div className="card">
          <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Creative Direction Retainers</div>
          <p className="p">Ongoing design leadership — consistency, speed, and scale.</p>
        </div>
      </div>

      <div style={{ marginTop: 14 }} className="btnRow">
        <Link className="btn btnPrimary" href="/contact">Start a Project</Link>
        <Link className="btn" href="/dashboard">Open Dashboard</Link>
      </div>
    </Section>
  );
}
