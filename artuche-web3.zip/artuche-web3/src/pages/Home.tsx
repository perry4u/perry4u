import React from "react";
import Section from "../components/Section";
import Ecosystem from "../components/Ecosystem";
import Web3Panel from "../components/Web3Panel";
import { Link } from "wouter";

export default function Home() {
  return (
    <>
      <section style={{ padding: "70px 0 34px" }}>
        <div className="container">
          <div className="pill">Creative Intelligence • Culture • Future Infrastructure</div>
          <h1 className="h1">ARTUCHE</h1>
          <p className="p" style={{ maxWidth: 820, fontSize: 16 }}>
            ARTUCHE is a creative intelligence ecosystem building future-ready systems for brands, platforms, and people —
            designed to remain relevant as culture and technology evolve.
          </p>

          <div className="btnRow" style={{ marginTop: 18 }}>
            <Link href="/contact" className="btn btnPrimary">Start a Project</Link>
            <a href="#ecosystem" className="btn">Explore the Ecosystem</a>
          </div>

          <div style={{ marginTop: 18 }} className="small">
            Web3-ready: connect wallet + gate sign-in to unlock Labs/Academy and use Dashboard.
          </div>
        </div>
      </section>

      <Section title="Web3 Gateway" kicker="Access Layer">
        <Web3Panel />
      </Section>

      <Section title="What We Build" kicker="Pillars">
        <div className="grid3">
          <div className="card">
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Creative Intelligence</div>
            <p className="p">We translate vision into structured systems that scale.</p>
          </div>
          <div className="card">
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Culture-Led Design</div>
            <p className="p">We build meaning before aesthetics, so brands last.</p>
          </div>
          <div className="card">
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Future Infrastructure</div>
            <p className="p">Frameworks for tomorrow — not temporary trends.</p>
          </div>
        </div>
      </Section>

      <Section title="The Ecosystem" kicker="Divisions">
        <div id="ecosystem" />
        <Ecosystem />
      </Section>

      <Section title="Method" kicker="How We Work">
        <div className="grid3">
          <div className="card"><div className="h2" style={{ margin: 0 }}>01</div><p className="p">Discover: research, clarity, strategic direction.</p></div>
          <div className="card"><div className="h2" style={{ margin: 0 }}>02</div><p className="p">Design Systems: identity, experience, structure.</p></div>
          <div className="card"><div className="h2" style={{ margin: 0 }}>03</div><p className="p">Deploy & Scale: assets, governance, longevity.</p></div>
        </div>
      </Section>

      <Section title="Build Something That Lasts" kicker="Next Step">
        <div className="card" style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: 14, flexWrap: "wrap" }}>
          <p className="p" style={{ maxWidth: 740 }}>
            Whether you’re launching, scaling, or redefining your direction — ARTUCHE provides the structure.
          </p>
          <Link href="/contact" className="btn btnPrimary">Book a Discovery Call</Link>
        </div>
      </Section>
    </>
  );
}
