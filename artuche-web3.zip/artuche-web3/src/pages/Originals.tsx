import React from "react";
import Section from "../components/Section";

export default function Originals() {
  return (
    <Section title="ARTUCHE Originals" kicker="IP Engine">
      <div className="card">
        <p className="p">
          Original content, media, and cultural works built as long-term IP — film, music, digital culture, and story systems.
        </p>
      </div>
    </Section>
  );
}
