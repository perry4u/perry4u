import React from "react";
import Section from "../components/Section";
import Gate from "../components/Gate";

export default function Academy() {
  return (
    <Section title="ARTUCHE Academy" kicker="People Engine">
      <Gate>
        <div className="card">
          <p className="p">
            Training creative intelligence for the next era — future branding, creative systems, digital tools, and cultural leadership.
          </p>
          <div className="hr" />
          <p className="p">
            Gated content example: modules, cohorts, certificates, member-only downloads.
          </p>
        </div>
      </Gate>
    </Section>
  );
}
