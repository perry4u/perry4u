import React, { useMemo } from "react";
import { useAccount, useChainId } from "wagmi";
import Section from "../components/Section";
import EnsProfile from "../components/EnsProfile";
import NFTRoles from "../components/NFTRoles";
import TokenBalances from "../components/TokenBalances";
import NFTGallery from "../components/NFTGallery";
import Gate from "../components/Gate";
import { isGatedIn } from "../lib/gate";
import { Link } from "wouter";

export default function Dashboard() {
  const { address, isConnected } = useAccount();
  const chainId = useChainId();

  const short = useMemo(() => {
    if (!address) return "";
    return `${address.slice(0, 6)}…${address.slice(-4)}`;
  }, [address]);

  return (
    <>
      <Section title="Dashboard" kicker="Ecosystem Access">
        <div className="card">
          <div style={{ display: "flex", justifyContent: "space-between", gap: 14, flexWrap: "wrap" }}>
            <div>
              <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Status</div>
              <p className="p" style={{ marginTop: 8 }}>
                {isConnected ? (
                  <>
                    Connected: <b style={{ color: "white" }}>{short}</b> • ChainID{" "}
                    <b style={{ color: "white" }}>{chainId}</b> •{" "}
                    {isGatedIn() ? <b style={{ color: "white" }}>✅ Gated In</b> : <b style={{ color: "white" }}>🔒 Locked</b>}
                  </>
                ) : (
                  <>Not connected. Go to Home to connect your wallet.</>
                )}
              </p>
            </div>

            <div className="btnRow">
              <Link className="btn btnPrimary" href="/">Home (Connect)</Link>
              <Link className="btn" href="/labs">Labs</Link>
              <Link className="btn" href="/academy">Academy</Link>
            </div>
          </div>
        </div>
      </Section>


      <Section title="Identity" kicker="ENS + Roles">
        <div className="grid3">
          <EnsProfile />
          <NFTRoles />
          <div className="card">
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Access Notes</div>
            <div className="small">Configure admins, role NFTs, and Stripe link in <code>.env</code>.</div>
            <div className="hr" />
            <div className="small">• VITE_ADMIN_ADDRESSES</div>
            <div className="small">• VITE_ROLE_NFT_CONTRACTS</div>
            <div className="small">• VITE_STRIPE_PAYMENT_LINK</div>
          </div>
        </div>
      </Section>

      <Section title="Tokens" kicker="Onchain">
        <TokenBalances />
      </Section>

      <Section title="NFTs" kicker="Indexing">
        <NFTGallery />
      </Section>

      <Section title="Gated Content Preview" kicker="Locked Areas">
        <Gate>
          <div className="card">
            <div style={{ letterSpacing: ".08em", textTransform: "uppercase" }}>Unlocked</div>
            <p className="p" style={{ marginTop: 10 }}>
              You are gated in. This area can show private Labs research, Academy modules,
              investor materials, or partner-only documentation.
            </p>
          </div>
        </Gate>
      </Section>
    </>
  );
}
