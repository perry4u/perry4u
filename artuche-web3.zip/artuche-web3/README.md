# ARTUCHE Web3 Website (Vite + React + TS)

## Quick start (Replit / local)
1) Copy `env.example` to `.env` and fill values:
   - VITE_WALLETCONNECT_PROJECT_ID (optional)
   - VITE_ALCHEMY_API_KEY (required for NFTs)
   - VITE_ALCHEMY_NETWORK (default: eth-mainnet)

2) Install and run:
```bash
npm install
npm run dev
```

Open on port 3000.

## Features
- Multi-page routing (wouter)
- Wallet connect (wagmi + viem): MetaMask injected + WalletConnect (if env var exists)
- Signature-based gate (sessionStorage) to lock Labs & Academy
- Token balances via onchain ERC-20 reads (USDC/USDT/DAI mainnet)
- NFT Gallery via Alchemy NFT API
- Dashboard (/dashboard) unifies everything
